class ImageAssets {
  static const avatar = "avatar";
  static const loadingImage = "loading_image";
  static const splash = "splash";
}
